
public class Assignment4_4 {
	
	String name;
	int age;
	String Profession;
	
//	Parameterized constructor of super class
	public Assignment4_4(String name, int age, String profession) {
		
		this.name = name;
		this.age = age;
		Profession = profession;
		
		System.out.println("Super class constructer called..!!");
	}
	
	
}
