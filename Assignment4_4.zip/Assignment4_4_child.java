
public class Assignment4_4_child extends Assignment4_4{

//	It must be declared because parent class having parameterized constructor
	public Assignment4_4_child(String name, int age, String profession) {
		super(name, age, profession);
		
	}
	
	
	public static void main(String[] args) {
		
//	Going to call super class constructor
		System.out.println("Going to call super class constructor...");
		Assignment4_4_child obj = new Assignment4_4_child("Mayank",23,"Engineer");
		
		System.out.println("Back to child class.");
//		Display the values passed through constructor
		System.out.println("Name = " + obj.name);
		System.out.println("Age = " + obj.age);
		System.out.println("Profession = " + obj.Profession);
	}
	

}
